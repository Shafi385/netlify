import React, { useState } from 'react';
import { ImageIcon, Loader2, SendIcon, Settings2Icon } from 'lucide-react';

const API_HOST = 'https://api.stability.ai';

function App() {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const generateImage = async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt');
      return;
    }

    const apiKey = import.meta.env.VITE_STABILITY_API_KEY;
    if (!apiKey) {
      setError('Missing API key. Please add your Stability API key to the .env file.');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(
        `${API_HOST}/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            text_prompts: [
              {
                text: prompt,
                weight: 1,
              },
            ],
            cfg_scale: 7,
            height: 1024,
            width: 1024,
            steps: 50,
            samples: 1,
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to generate image');
      }

      const responseJSON = await response.json();
      const base64Image = responseJSON.artifacts[0].base64;
      setImage(`data:image/png;base64,${base64Image}`);
    } catch (err) {
      console.error('Generation error:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate image. Please check your API key and try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-2">
            <ImageIcon className="w-8 h-8" />
            AI Image Generator
          </h1>
          <p className="text-gray-400">Transform your ideas into stunning visuals with Stability AI</p>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 shadow-xl mb-8">
          <div className="flex gap-4">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the image you want to generate..."
              className="flex-1 px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition"
              onKeyPress={(e) => e.key === 'Enter' && generateImage()}
            />
            <button
              onClick={generateImage}
              disabled={loading}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-2 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <SendIcon className="w-5 h-5" />
                  Generate
                </>
              )}
            </button>
          </div>
          {error && (
            <p className="text-red-400 mt-2">{error}</p>
          )}
          <div className="mt-4 flex items-center gap-2 text-sm text-gray-400">
            <Settings2Icon className="w-4 h-4" />
            <span>Using Stable Diffusion XL 1.0 | 1024x1024px | 50 Steps</span>
          </div>
        </div>

        <div className="flex justify-center">
          {image ? (
            <div className="relative group">
              <img
                src={image}
                alt={prompt}
                className="rounded-lg shadow-2xl max-w-full max-h-[600px] object-contain"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 rounded-lg flex items-center justify-center">
                <a
                  href={image}
                  download={`ai-generation-${Date.now()}.png`}
                  className="opacity-0 group-hover:opacity-100 bg-white text-black px-4 py-2 rounded-lg transition-all duration-300"
                >
                  Download Image
                </a>
              </div>
            </div>
          ) : (
            <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center text-gray-500">
              <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>Your generated image will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;